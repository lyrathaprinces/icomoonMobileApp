import Icon from "./icon/Icons.component";

export {
    Icon,
}